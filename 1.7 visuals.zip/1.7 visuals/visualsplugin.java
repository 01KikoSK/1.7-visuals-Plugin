package com.example.visualsplugin;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.entity.Player;

public class VisualsPlugin extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        getLogger().info("VisualsPlugin bol zapnutý!");
        // Registrácia listenera
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        getLogger().info("VisualsPlugin bol vypnutý!");
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Location loc = player.getLocation();

        // Vytvorenie kruhu častíc okolo hráča
        for (double angle = 0; angle < Math.PI * 2; angle += Math.PI / 8) {
            double offsetX = Math.cos(angle) * 2; // polomer 2 bloky
            double offsetZ = Math.sin(angle) * 2;
            Location particleLocation = new Location(loc.getWorld(), loc.getX() + offsetX, loc.getY() + 1, loc.getZ() + offsetZ);
            // Použitie častice, tu VILLAGER_HAPPY ako príklad; môžeš vymeniť za inú
            loc.getWorld().spawnParticle(Particle.VILLAGER_HAPPY, particleLocation, 0, 0, 0, 0, 0.1);
        }
    }
}